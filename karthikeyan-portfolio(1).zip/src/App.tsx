import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import ParticleBackground from './components/ParticleBackground';
import ScrollProgress from './components/ScrollProgress';
import LoadingScreen from './components/LoadingScreen';
import Navbar from './components/Navbar';
import Hero from './sections/Hero';
import About from './sections/About';
import Skills from './sections/Skills';
import Projects from './sections/Projects';
import GitHubSection from './sections/GitHub';
import Education from './sections/Education';
import Contact from './sections/Contact';
import Footer from './sections/Footer';
import { useMousePosition } from './hooks/useMousePosition';

const App: React.FC = () => {
  const [isLoading, setIsLoading] = useState(true);
  const mousePosition = useMousePosition();

  const handleLoadingComplete = useCallback(() => {
    setIsLoading(false);
  }, []);

  useEffect(() => {
    if (!isLoading) {
      document.documentElement.style.setProperty('--cursor-x', `${mousePosition.x}px`);
      document.documentElement.style.setProperty('--cursor-y', `${mousePosition.y}px`);
    }
  }, [mousePosition, isLoading]);

  return (
    <>
      <AnimatePresence>
        {isLoading && <LoadingScreen onComplete={handleLoadingComplete} />}
      </AnimatePresence>

      {!isLoading && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8 }}
          className="relative min-h-screen bg-background"
        >
          {/* Cursor Glow Effect */}
          <div
            className="cursor-glow hidden lg:block"
            style={{
              left: mousePosition.x,
              top: mousePosition.y,
            }}
          />

          {/* Particle Background */}
          <ParticleBackground />

          {/* Scroll Progress */}
          <ScrollProgress />

          {/* Navigation */}
          <Navbar />

          {/* Main Content */}
          <main className="relative z-10">
            <Hero />
            <About />
            <Skills />
            <Projects />
            <GitHubSection />
            <Education />
            <Contact />
          </main>

          {/* Footer */}
          <Footer />
        </motion.div>
      )}
    </>
  );
};

export default App;
